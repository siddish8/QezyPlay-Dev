<?php

/* Includes config,db and table definitions and common functions files */	


define("DB_SERVER","50.62.170.42");	
define("DB_USER","tradmin_qezyplay");
define("DB_PASSWORD","&(qezy@word)&");
define("DB_NAME","tradmin_newqezy");


/* Include db & data files */
require_once("common_functions.php");
require_once("classes/dbconfig.class.php");  //DB connection
require_once("classes/servicedata.class.php");

define("TOKEN_SECRET_KEY", "QezyplayIB");

?>
